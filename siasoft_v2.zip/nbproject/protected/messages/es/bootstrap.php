<?php
	return array(
		// Traducciones del menu
		'Home' => 'Inicio',
	)
?>