<?php 
 return array(
	'CommentIndex',
	'PostView',
	'PostIndex',
	'SiteCaptcha',
	'SitePage',
	'SiteError',
	'SiteContact',
	'SiteLogin',
	'SiteLogout'
);
?>