<?php
$this->breadcrumbs=array(
	'Configuracion Inventario'=>array('admin'),
	'Crear',
);

?>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>