<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('PROVEEDOR')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->PROVEEDOR), array('view', 'id'=>$data->PROVEEDOR)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CATEGORIA')); ?>:</b>
	<?php echo CHtml::encode($data->CATEGORIA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NOMBRE')); ?>:</b>
	<?php echo CHtml::encode($data->NOMBRE); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ALIAS')); ?>:</b>
	<?php echo CHtml::encode($data->ALIAS); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CONTACTO')); ?>:</b>
	<?php echo CHtml::encode($data->CONTACTO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CARGO')); ?>:</b>
	<?php echo CHtml::encode($data->CARGO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('DIRECCION')); ?>:</b>
	<?php echo CHtml::encode($data->DIRECCION); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('EMAIL')); ?>:</b>
	<?php echo CHtml::encode($data->EMAIL); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_INGRESO')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_INGRESO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TELEFONO1')); ?>:</b>
	<?php echo CHtml::encode($data->TELEFONO1); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TELEFONO2')); ?>:</b>
	<?php echo CHtml::encode($data->TELEFONO2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FAX')); ?>:</b>
	<?php echo CHtml::encode($data->FAX); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('NIT')); ?>:</b>
	<?php echo CHtml::encode($data->NIT); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CONDICION_PAGO')); ?>:</b>
	<?php echo CHtml::encode($data->CONDICION_PAGO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ACTIVO')); ?>:</b>
	<?php echo CHtml::encode($data->ACTIVO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ORDEN_MINIMA')); ?>:</b>
	<?php echo CHtml::encode($data->ORDEN_MINIMA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('DESCUENTO')); ?>:</b>
	<?php echo CHtml::encode($data->DESCUENTO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TASA_INTERES_MORA')); ?>:</b>
	<?php echo CHtml::encode($data->TASA_INTERES_MORA); ?>
	<br />

	*/ ?>

</div>